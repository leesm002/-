package com.example.simplememo;

import android.view.View;

public interface MemoItemClickListener {
    public void onMemoItemClick(View v, int index);
}
